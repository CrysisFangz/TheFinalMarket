class EscrowTransaction < ApplicationRecord
  belongs_to :escrow_wallet
  belongs_to :order
  belongs_to :sender, class_name: 'User'
  belongs_to :receiver, class_name: 'User'

  enum status: {
    pending: 0,
    held: 1,
    released: 2,
    refunded: 3,
    disputed: 4,
    partially_refunded: 5
  }

  validates :amount, presence: true, numericality: { greater_than: 0 }
  validates :status, presence: true
  validates :transaction_type, presence: true
  validates :sender_id, presence: true
  validates :receiver_id, presence: true
  validate :sender_and_receiver_are_different
  validate :release_at_must_be_future_date, if: :release_at?

  scope :pending_finalization, -> { where(status: :held).where('created_at <= ?', 7.days.ago) }
  scope :needs_admin_approval, -> { where(status: :held, needs_admin_approval: true) }

  # Prevent circular transactions
  def sender_and_receiver_are_different
    if sender_id.present? && sender_id == receiver_id
      errors.add(:receiver_id, "cannot be the same as sender")
    end
  end

  # Ensure release date is in the future
  def release_at_must_be_future_date
    if release_at.present? && release_at <= Time.current
      errors.add(:release_at, "must be a future date")
    end
  end

  def hold_funds
    if escrow_wallet.hold_funds(amount)
      update(status: :held)
      notify_parties("Funds held in escrow")
      true
    else
      errors.add(:base, "Insufficient funds")
      false
    end
  end

  def release_funds(admin_approved: false)
    # Idempotency check
    return true if released?
    
    return false unless can_release_funds?(admin_approved)

    ActiveRecord::Base.transaction do
      # Double-check status hasn't changed (optimistic locking)
      reload
      raise ActiveRecord::RecordInvalid, "Transaction already processed" unless held?
      
      # Verify wallet balances before proceeding
      raise ActiveRecord::RecordInvalid, "Insufficient escrow balance" if escrow_wallet.balance < amount
      
      receiver.escrow_wallet.receive_funds(amount)
      escrow_wallet.release_funds(amount)
      update!(status: :released, admin_approved_at: admin_approved ? Time.current : nil)
      notify_parties("Funds released to seller")
    end
    true
  rescue ActiveRecord::RecordInvalid => e
    errors.add(:base, "Validation failed: #{e.message}")
    Rails.logger.error("Escrow release failed for transaction #{id}: #{e.message}")
    false
  rescue => e
    errors.add(:base, "Failed to release funds: #{e.message}")
    Rails.logger.error("Escrow release failed for transaction #{id}: #{e.class} - #{e.message}")
    Rails.logger.error(e.backtrace.join("\n"))
    false
  end

  def refund(refund_amount = nil, admin_approved: false)
    # Idempotency check
    return true if refunded? || (partially_refunded? && refund_amount.nil?)
    
    return false unless can_refund?(admin_approved)

    refund_amount ||= amount
    
    # Validate refund amount
    if refund_amount <= 0 || refund_amount > amount
      errors.add(:base, "Invalid refund amount")
      return false
    end

    ActiveRecord::Base.transaction do
      reload
      
      # Verify transaction is still refundable
      unless held? || disputed?
        raise ActiveRecord::RecordInvalid, "Transaction cannot be refunded in current state"
      end
      
      # Verify escrow has sufficient funds
      raise ActiveRecord::RecordInvalid, "Insufficient escrow balance" if escrow_wallet.balance < refund_amount
      
      sender.escrow_wallet.receive_funds(refund_amount)
      escrow_wallet.release_funds(refund_amount)
      
      if refund_amount == amount
        update!(status: :refunded, refunded_at: Time.current, refunded_amount: refund_amount)
      else
        update!(status: :partially_refunded, refunded_at: Time.current, refunded_amount: refund_amount)
      end
      
      notify_parties("Refund processed: #{Money.new(refund_amount * 100, 'USD').format}")
    end
    true
  rescue ActiveRecord::RecordInvalid => e
    errors.add(:base, "Validation failed: #{e.message}")
    Rails.logger.error("Escrow refund failed for transaction #{id}: #{e.message}")
    false
  rescue => e
    errors.add(:base, "Failed to process refund: #{e.message}")
    Rails.logger.error("Escrow refund failed for transaction #{id}: #{e.class} - #{e.message}")
    Rails.logger.error(e.backtrace.join("\n"))
    false
  end

  def initiate_dispute
    return false if disputed?
    
    transaction do
      update(status: :disputed)
      dispute = order.create_dispute!(
        buyer: sender,
        seller: receiver,
        amount: amount,
        escrow_transaction: self
      )
      notify_parties("Dispute initiated")
      DisputeAssignmentService.new(dispute).assign_mediator
    end
    true
  rescue => e
    errors.add(:base, "Failed to initiate dispute: #{e.message}")
    false
  end

  private

  def can_release_funds?(admin_approved)
    return false unless held?
    return true if admin_approved
    return false if needs_admin_approval && !admin_approved
    true
  end

  def can_refund?(admin_approved)
    return false unless held? || disputed?
    return true if admin_approved
    return false if needs_admin_approval && !admin_approved
    true
  end

  def notify_parties(message)
    [sender, receiver].each do |user|
      NotificationService.notify(
        user: user,
        title: "Escrow Update",
        message: message,
        resource: self
      )
    end
  end
end